POWER QUERY PRACTICE DATASET

Files:
- sales_all.csv: 8,000 transaction records with intentionally inconsistent values/date formats.
- sales_YYYY_MM.csv: monthly files for Folder Combine practice.
- customers.xlsx: customer master.
- products.xlsx: product master.
- stores.xlsx: store/location master.
- employees.xlsx: employee master.
- returns.csv: returns data.
- targets.json: monthly regional targets.
- store_targets_nested.json: nested JSON for expand/transform practice.
- messy_customer_master.xlsx: intentionally messy workbook.

Suggested exercises:
1. Import CSV/XLSX/JSON.
2. Fix data types and date formats.
3. Trim/clean text.
4. Handle nulls and errors.
5. Remove duplicates.
6. Merge Sales + Customers.
7. Merge Sales + Products.
8. Merge Sales + Stores.
9. Append monthly Sales CSV files.
10. Group by month/category/region.
11. Pivot and unpivot.
12. Expand nested JSON.
13. Create conditional columns.
14. Create custom columns for Gross Profit and Margin.
15. Build a reusable folder-combine query.
16. Create parameters for file path and date range.
17. Load the final model into Power BI and build a sales dashboard.
